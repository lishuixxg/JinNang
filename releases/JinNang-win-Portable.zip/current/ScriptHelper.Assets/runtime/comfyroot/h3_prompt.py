from __future__ import annotations

import math
import random
import re
from pathlib import Path

from .bonsai_nodes import (
    BONSAI_MODEL_DIR,
    BONSAI_RUNTIME_DIR,
    SERVER,
    _clean_prompt,
    _data_url,
    _find_one,
    _post_json,
    _release_comfy_models,
    _tensor_frame_to_pil,
)


H3_SKILL_ROOT = Path(__file__).resolve().parent / "h3_skills"
BASE_SKILL_ID = "h3-prompt-writing"
H3_MODES = {
    "文本生成视频 (T2VA)": "T2VA",
    "首帧生成视频 (I2VA)": "I2VA",
    "首尾帧生成视频 (FL2VA)": "FL2VA",
    "尾帧生成视频 (L2VA)": "L2VA",
    "全参考生成视频 (Ref2VA)": "Ref2VA",
}
ASPECT_RATIOS = {
    "1:1": (1, 1),
    "2:3": (2, 3),
    "3:2": (3, 2),
    "3:4": (3, 4),
    "4:3": (4, 3),
    "9:16": (9, 16),
    "16:9": (16, 9),
    "21:9": (21, 9),
}
H3_FPS = 24
H3_FRAME_REMAINDER = 5
H3_FRAME_INTERVAL = 17
H3_CANVAS_MULTIPLE = 32
DEFAULT_MEGAPIXELS = 0.4
DEFAULT_BONSAI_CONTEXT_SIZE = 32768
EXPANDED_BONSAI_CONTEXT_SIZE = 65536
MAX_BONSAI_CONTEXT_SIZE = 131072
SKILL_LANGUAGE = {
    "严格遵循官方（英文）": "Official English",
    "优先使用中文": "Chinese if available",
    "仅英文": "English",
    "仅中文": "Chinese",
    "中英文都使用": "Both",
}
REFERENCE_DEPTH = {
    "仅使用 Skill": "Skill only",
    "Skill 与参考资料": "Skill with references",
}
OUTPUT_FORMAT = {
    "仅输出 H3 提示词": "H3 prompt only",
    "输出 H3 提示词和简要说明": "H3 prompt with brief notes",
}
PROFESSIONAL_STORYBOARD_SKILL_ID = "professional-chinese-sales-storyboard"
MAX_CHAT_NEW_TOKENS = 8192
PROFESSIONAL_MIN_NEW_TOKENS = 2048
SKILL_NAMES = {
    "h3-prompt-writing": "H3 通用提示词编写",
    "3d-animation-short-generator": "3D 动画短片",
    "brand-promo-video-generator": "品牌宣传片",
    "co-op-game-intro-generator": "合作游戏开场",
    "handdrawn-live-video-generator": "手绘实拍视频",
    "minimalist-product-ad-generator": "极简产品广告",
    "music-video-subtitle-generator": "MV 字幕视频",
    "paper-collage-explainer-generator": "纸艺拼贴讲解",
    "papercraft-stop-motion-explainer": "纸艺定格动画",
    PROFESSIONAL_STORYBOARD_SKILL_ID: "中文带货视频",
}


def _skill_ids() -> list[str]:
    if not H3_SKILL_ROOT.exists():
        return [BASE_SKILL_ID]

    ids = [
        p.name
        for p in H3_SKILL_ROOT.iterdir()
        if p.is_dir() and (p / "SKILL.md").exists()
    ]
    ids.sort()
    if BASE_SKILL_ID in ids:
        ids.remove(BASE_SKILL_ID)
        ids.insert(0, BASE_SKILL_ID)
    return ids or [BASE_SKILL_ID]


def _skill_choices() -> list[str]:
    choices = [SKILL_NAMES.get(skill_id, skill_id) for skill_id in _skill_ids()]
    professional = SKILL_NAMES[PROFESSIONAL_STORYBOARD_SKILL_ID]
    if professional not in choices:
        choices.append(professional)
    return choices


def _normalize_choice(value: str, choices: dict[str, str]) -> str:
    return choices.get(value, value)


def _normalize_skill(value: str) -> str:
    for skill_id, label in SKILL_NAMES.items():
        if value == label:
            return skill_id
    return value


def _h3_frame_count(duration_seconds: float) -> int:
    frame_count = max(H3_FRAME_REMAINDER, round(duration_seconds * H3_FPS))
    return frame_count + (H3_FRAME_REMAINDER - frame_count % H3_FRAME_INTERVAL) % H3_FRAME_INTERVAL


def _h3_resolution(aspect_ratio: str, megapixels: float) -> tuple[int, int]:
    width_ratio, height_ratio = ASPECT_RATIOS[aspect_ratio]
    total_pixels = megapixels * 1024 * 1024
    scale = math.sqrt(total_pixels / (width_ratio * height_ratio))
    width = round(width_ratio * scale / H3_CANVAS_MULTIPLE) * H3_CANVAS_MULTIPLE
    height = round(height_ratio * scale / H3_CANVAS_MULTIPLE) * H3_CANVAS_MULTIPLE
    return width, height


def _normalize_megapixels(value) -> float:
    try:
        megapixels = float(value)
    except (TypeError, ValueError):
        return DEFAULT_MEGAPIXELS
    if not math.isfinite(megapixels):
        return DEFAULT_MEGAPIXELS
    return min(16.0, max(0.1, megapixels))


def _normalize_duration(value, fallback: float = 6.0) -> float:
    try:
        duration = float(value)
    except (TypeError, ValueError):
        duration = fallback
    if not math.isfinite(duration) or duration <= 0:
        duration = fallback
    return min(15.0, max(4.0, duration))


def _normalize_aspect_ratio(value: str) -> str:
    return value.split(" ", 1)[0]


def _aspect_ratio_from_dimensions(width: int, height: int) -> str:
    ratio = width / max(1, height)
    return min(
        ASPECT_RATIOS,
        key=lambda name: abs(ASPECT_RATIOS[name][0] / ASPECT_RATIOS[name][1] - ratio),
    )


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def _append_file(
    parts: list[str],
    path: Path,
    title: str,
) -> None:
    if path.exists():
        text = _read_text(path)
        if text:
            parts.append(f"## {title}\n\n{text}")


def _append_reference_files(
    parts: list[str],
    skill_dir: Path,
    skill_id: str,
) -> None:
    ref_dir = skill_dir / "references"
    if not ref_dir.exists():
        return

    for path in sorted(ref_dir.glob("*.md")) + sorted(ref_dir.glob("*.txt")):
        _append_file(
            parts,
            path,
            f"{skill_id}/{path.relative_to(skill_dir).as_posix()}",
        )


def _append_skill_file(
    parts: list[str],
    skill_dir: Path,
    skill_id: str,
    skill_language: str,
) -> None:
    cn_path = skill_dir / "SKILL.cn.md"
    en_path = skill_dir / "SKILL.md"

    if skill_language in {"Official English", "English"}:
        _append_file(parts, en_path, f"{skill_id}/SKILL.md")
    elif skill_language == "Chinese":
        _append_file(
            parts,
            cn_path if cn_path.exists() else en_path,
            f"{skill_id}/SKILL",
        )
    elif skill_language == "Both":
        _append_file(parts, cn_path, f"{skill_id}/SKILL.cn.md")
        _append_file(parts, en_path, f"{skill_id}/SKILL.md")
    else:
        _append_file(
            parts,
            cn_path if cn_path.exists() else en_path,
            f"{skill_id}/SKILL",
        )


def _append_output_language_policy(parts: list[str], skill_language: str) -> None:
    if skill_language in {"Chinese if available", "Chinese"}:
        parts.append(
            "Mandatory final output language: Simplified Chinese. The final answer is invalid if descriptive "
            "prompt prose is written in English. "
            "Keep the official English field names, section names, reference labels such as <Subject N>, "
            "<Picture N>, <Video N>, and <Audio N>, shot labels such as [Shot N], timing notation, XML-like "
            "tags, model names, and user-provided dialogue, lyrics, or visible text exactly as required by the "
            "official guide. Do not translate those structural tokens. If the official guide or examples are "
            "in English, translate their descriptive style and requirements into Simplified Chinese."
        )
    elif skill_language == "Both":
        parts.append(
            "Final output language policy: write the complete official H3 prompt in Simplified Chinese first, "
            "then provide an English version with the same structure. Keep official field names, section names, "
            "reference labels, shot labels, timing notation, XML-like tags, model names, and user-provided "
            "dialogue, lyrics, or visible text unchanged where the guide requires them."
        )
    else:
        parts.append(
            "Final output language policy: write all natural-language prompt prose in English. "
            "Keep the official field names, reference labels, shot labels, timing notation, XML-like tags, "
            "model names, and user-provided dialogue, lyrics, or visible text as required by the official guide."
        )


def _append_professional_storyboard_role(parts: list[str]) -> None:
    parts.append(
        "When the selected skill is Professional Chinese sales storyboard, convert the official H3 prompt requirements "
        "into a polished Chinese short-video prompt using exactly this bracket-section structure. Preserve the original "
        "Chinese e-commerce director role, its detailed product analysis, timed sales copy, shot planning, transitions, "
        "camera design, sound design, and strict constraints. Treat every concrete request in source_prompt and "
        "extra_requirements as binding: explicitly integrate all requested actions, product features, shot assignments, "
        "transitions, wardrobe or prop states, speaking conditions, and final-frame conditions instead of replacing them "
        "with generic sales beats. Return only the prompt text, with no Markdown code fence, "
        "explanation, or notes.\n\n"
        "Required section order:\n"
        "【全局参数】\n"
        "State total duration, aspect ratio, generation mode, realism/style, target live-commerce purpose, subtitle/text "
        "policy, audio/dialogue policy, and shot count. Use the workflow duration and aspect ratio provided by the node. "
        "State explicitly that the whole video has no subtitles, captions, title text, stickers, floating text, corner "
        "labels, logos, or watermarks. Define the visual style as an absolutely photorealistic, real-camera, real-person "
        "live-commerce or product-demonstration recording. Never describe the default style as a short drama, narrative film, "
        "cinematic story, MV, theatrical performance, or staged advertising performance. Unless the user explicitly requests "
        "an opening pause or delayed dialogue, use no silent visual pre-roll: the first on-camera sales line starts at 0.00 seconds, "
        "and its first audible phoneme and the presenter's first visible lip/jaw movement start together immediately. Do not impose "
        "a default speech-free ending; follow the requested final shot and place its line inside that shot, using off-screen "
        "voiceover when the visible subject should not speak. Use nearly all suitable timeline for speech. "
        "User instructions about "
        "whether speech exists, which shots speak, exact dialogue, segment count, timing, voice, and lip-sync always take priority "
        "over defaults. For a 15-second sales video with no user-specified script density or speed, default to a fast e-commerce "
        "cadence with one continuous energetic sales delivery organized into 4-5 compact cue ranges. For reliability, reduce the "
        "previous fast-script density by about 25%: aim for roughly 60-70 spoken Chinese characters in total, normally 14-18 "
        "characters per cue, at about 5.0-5.6 Chinese characters per second. Use "
        "connected phrase bursts, crisp consonants, short emphatic stresses, and only 0.05-0.12 second micro-pauses at meaningful "
        "selling-point boundaries. In every shot that contains speech, the total silent time before, inside, or after that shot's "
        "spoken line must never exceed 0.50 second; it may be shorter or zero. Prefer 0.00-0.20 second gaps and allow speech to "
        "continue directly across a cut. Never reset to a slow cadence "
        "after a shot cut. Treat 40-50 total characters and about 3.8-4.5 characters per second as medium speed, not the default. "
        "Use medium or slow speed only when the user explicitly asks for it. Do not draw out syllables, insert leisurely pauses, "
        "or read characters one by one. If a cue cannot safely fit, shorten and sharpen its copy while retaining the fast rhythm "
        "instead of slowing the delivery; never sacrifice intelligibility, pronunciation, audio stability, or lip-sync accuracy. "
        "Make the dialogue lexically varied across shots. Unless the user supplies exact words that must be preserved, do not repeat "
        "the same core product noun, selling adjective, benefit phrase, opening formula, or CTA wording in multiple <d> blocks. Say "
        "the full product name normally once in the first cue, then use natural references such as 这件、这套、它 or omit the noun. "
        "Words and ideas such as 柔软、舒服、亲肤、宽松、透气、轻盈、自在、安心 must not be recycled across several cues merely "
        "with reordered syntax. Give every shot a distinct semantic job—overall introduction, material/touch, cut/mobility, functional "
        "detail, use outcome, or CTA—and silently compare all dialogue blocks for repeated content words before answering. Repetition "
        "is allowed only for user-mandated exact dialogue, indispensable brand/model names, or ordinary grammatical function words. "
        "For every visible lip-sync cue, write an audio start and end time calculated from its character count and requested pace. "
        "Count Chinese characters while excluding punctuation, then calculate duration as character_count divided by the selected "
        "characters-per-second rate. At the default 5.0-5.6 rate, a 14-character line requires about 2.5-2.8 seconds and must never "
        "be described as ending after only 0.62 second. Round speech times to practical 0.1-second precision rather than inventing "
        "hundredth- or thousandth-second precision. Make the spoken line occupy nearly all of its assigned shot, leaving at most "
        "0.50 second of total silence in that shot. Calculate each shot's required dialogue length from (shot_duration minus no more "
        "than 0.50 second) multiplied by the selected speaking rate; do not force every differently sized shot to use the same number "
        "of characters. The first audible phoneme and the first visible lip/jaw movement must begin on the same frame; audio must never lead "
        "the mouth. If the input reference has a closed mouth, use it only for identity and composition and make the mouth begin "
        "speaking in the first generated motion immediately after the reference frame; never preserve closed lips as a timed hold. "
        "At the exact cue end, the voice stops and the lips close together.\n\n"
        "【人物与产品设定】\n"
        "Describe the main person, identity stability, wardrobe, environment, lighting, product/object appearance, material, "
        "color, scale, and consistency constraints. Preserve details visible in the reference images. Do not invent brands, "
        "prices, discounts, certifications, ingredients, performance figures, medical claims, or unsupported product features. "
        "Also define one stable natural speaking voice for each speaker. If the user specifies voice, accent, age impression, "
        "pitch, timbre, or speaking speed, follow it exactly. Otherwise infer a suitable voice conservatively from the visible "
        "adult model's apparent age range, gender presentation, expression, temperament, scene, product category, and sales style. "
        "Do not invent a regional accent or an exact identity; when visual cues are uncertain, use a neutral natural adult Mandarin "
        "voice. Keep the same speaker's voice consistent across every shot.\n\n"
        "【分镜设计】\n"
        "Unless the user explicitly asks for 一镜到底, one continuous take, or no cuts, always break the full duration into "
        "multiple numbered shots such as 分镜1（约0s-3.5s）. Never infer a one-take design merely from a static reference image, "
        "identity consistency, a stable camera request, or a request for realism. The shots exist to explain and sell the product "
        "more clearly: assign one primary product feature or selling point to each later shot and select an appropriate live-commerce "
        "view for it, such as presenter close-up, fabric macro, fit demonstration, functional detail, usage action, or final CTA. "
        "Avoid repeating the same composition or stacking every selling point into one static presenter shot. If the user explicitly "
        "requests one continuous take, preserve that instruction and design clear action beats within the uncut shot. Each shot must "
        "include subject action, "
        "camera movement, composition, transition intent, texture details, background continuity, and product/reference "
        "handling. Apply this lip-sync decision hierarchy exactly: (1) if the user requests every spoken segment to lip-sync, "
        "make every speaking shot show the speaker's visible mouth opening and matching the assigned cue; (2) if the user names "
        "specific lip-sync shots or says later shots need no lip-sync, follow those exact shot assignments; (3) if the user says "
        "nothing about lip-sync, the first suitable shot—normally 分镜1—must begin at 0.00 seconds as a clear on-camera sales "
        "presentation with no pre-roll, waiting pose, closed-mouth hold, silent observation, or preparatory action. At the first "
        "audible phoneme, the lips and jaw begin moving on exactly the same frame and accurately lip-sync the first line; there must "
        "be no speech before visible mouth movement and no mouth delay after audio begins. Keep the face and mouth unobstructed and "
        "the camera locked or nearly locked during the first spoken cue. Do not let eye contact, smiling, nodding, head turns, large "
        "hand gestures, fabric demonstrations, or camera movement happen before speech; small natural gestures may accompany speech "
        "only after reliable lip-sync has already started. "
        "For later cues, decide shot by shot: use visible lip-sync when the face and mouth are clear and direct selling fits the "
        "action; use an off-screen voiceover for product macro, fabric detail, transition, occluded face, distant view, or other "
        "shots where mouth movement would be visually inappropriate. For off-screen speech use the official phrase ‘says in an "
        "off-screen voiceover’ and state that any on-screen character's lips remain completely closed. Never ambiguously combine "
        "voiceover with mouth movement. Put all speech information directly inside the precise speaking shot: shot time, speaker "
        "identity and stable voice, on-camera lip-sync or off-screen mode, full exact dialogue, speaking action, mouth visibility, "
        "pace, pauses, exact audio start and end time, first-phoneme mouth start, and post-speech lip "
        "closure. Do not create a separate 【口播文案】 section or a separate cue index. Put the exact dialogue inline at "
        "the precise action point of every speaking shot. For "
        "visible lip-sync use, for example: ‘年轻女主播 (S1) says: <d>[Chinese] 这件衣服轻盈柔软，穿着很舒服。</d>，她正面对"
        "镜头自然张嘴说话，嘴部清晰可见，嘴唇开合、音节、节奏和停顿与该句逐字同步’. For voiceover use the exact official pattern: "
        "‘女主播 (S1) says in an off-screen voiceover: <d>[Chinese] ...</d>，镜头内人物嘴唇全程闭合’. Never place the same "
        "exact words in another shot, 【音效与音乐】, or any other section. Use absolute "
        "video timestamps everywhere: never write 0.00 seconds inside a later shot or restart timing at a shot boundary. Time ranges must cover the full video continuously "
        "without gaps or overlaps. For an otherwise unspecified 15-second product video, prefer 4-5 purposeful shots, with the first "
        "shot establishing the presenter and product through immediate lip-sync and later shots each demonstrating a different "
        "selling point. Every claimed selling point must come from the user or be conservatively supported by visible evidence; do "
        "not invent washing durability, anti-deformation, breathability, thermal, medical, or other performance claims just to fill "
        "a shot. Follow every user-specified scene, transition, state change, final image, and speaking requirement exactly. A requested "
        "state change overrides generic continuity defaults: if the user asks for clothing to be placed beside a sleeping subject, "
        "do not also say the subject is still wearing that clothing, and do not add a blanket or wardrobe rule that contradicts the "
        "requested final image. Before answering, audit global rules and every shot for mutually exclusive states: one garment cannot "
        "be simultaneously worn and placed elsewhere; a person cannot simultaneously wear and not wear glasses; a sleeping or "
        "off-screen-voiceover subject must not visibly lip-sync.\n\n"
        "【转场要求】\n"
        "List natural, practical transitions matched to real live-commerce product presentation, such as a direct cut, object wipe, "
        "fabric cover, reflection transition, "
        "hand/arm occlusion, hair wipe, foreground light wipe, liquid cover, or camera movement continuity. Forbid cheap "
        "jump cuts and spatially confusing transitions. Never turn the result into a short-drama or cinematic narrative style.\n\n"
        "【镜头与质感要求】\n"
        "Describe absolute photorealism and real-camera live-commerce footage: believable phone/camera framing, macro product detail, "
        "real skin and material texture, stable motion, practical indoor light, natural motion blur, and authentic product handling. "
        "Avoid short-drama styling, cinematic color grading, theatrical lighting, MV aesthetics, exaggerated depth of field, beauty-filter "
        "plastic skin, or staged narrative performance unless the user explicitly requests one of them.\n\n"
        "【音效与音乐】\n"
        "Describe clean native audio, environmental sounds, object Foley, voice clarity, background music style, volume "
        "relationship, and emotional progression. Require a lifelike human voice with natural breath, changing intonation, sentence "
        "stress, pitch movement, emotional warmth, and an energetic e-commerce rhythm matching the visible presenter. Deliver "
        "sentences in connected bursts, land a clear selling-point stress roughly every 1-1.5 seconds, keep momentum across cuts, "
        "and use only brief intentional micro-pauses rather than dead air. "
        "Forbid robotic cadence, constant pitch, mechanical text-to-speech delivery, metallic or vocoder-like tone, over-articulation, "
        "unnatural syllable spacing, and identical timing between phrases. Do not repeat or quote dialogue here, and do not let "
        "music cover speech.\n\n"
        "【严格约束】\n"
        "List negative constraints in Chinese and make the no-text rule unconditional: absolutely no subtitles, captions, "
        "title text, stickers, floating text, product callouts, corner labels, logos, or watermarks anywhere in the video. "
        "Also forbid extra people, identity drift, hand errors, product deformation, cheap filters, overexposure, plastic "
        "skin, abrupt spatial jumps, strong AI artifacts, any repeated or improvised spoken sentence, audible dialogue before "
        "visible mouth movement, delayed mouth motion after speech begins, lip-sync drift, lip movement during an "
        "off-screen voiceover, a speaking shot whose visible mouth is static, robotic or metallic voice, flat monotone delivery, "
        "unnatural word spacing, unstable speaker timbre, speech too fast for reliable pronunciation or lip-sync, an unrequested "
        "silent opening, an unrequested one-take composition, repeated static presenter framing, short-drama styling, and cinematic "
        "narrative staging. Also forbid more than 0.50 second of total silence in any shot that contains speech, incorrect dialogue-"
        "duration arithmetic, false sub-second delivery of a normal sentence, invented unsupported selling claims, and contradictions "
        "between global product rules and shot-level wardrobe, prop, glasses, sleeping, or final-frame states. Forbid repeated core "
        "sales words, repeated product nouns, repeated adjectives, repeated benefits, or near-duplicate sentence structures across "
        "different <d> blocks unless the user explicitly supplied those exact words.\n\n"
        "Style requirements: retain the original dense, professional, concrete, production-ready Chinese sales-video style. "
        "Prefer 800-1500 Chinese characters for normal requests, and more if max_new_tokens allows it. Keep user-provided "
        "visible text, dialogue, brand names, and reference labels exactly when needed."
    )


def _build_h3_system(
    skill_id: str,
    h3_mode: str,
    skill_language: str,
    reference_depth: str,
    output_format: str,
) -> str:
    if not H3_SKILL_ROOT.exists():
        raise FileNotFoundError(
            f"MiniMax H3 skill files are missing: {H3_SKILL_ROOT}"
        )
    parts = [
        "You are a MiniMax H3 prompt optimizer running inside ComfyUI.",
        "Use the complete official MiniMax H3 skill and mode-specific reference guide below as the authority. Do not omit, summarize, or weaken their requirements.",
        "This node only writes prompts; do not browse, download, call tools, or ask follow-up questions.",
        "Infer missing details conservatively from the text and attached images.",
        "Preserve the exact MiniMax H3 field names, section order, reference labels, and timing notation required by the official guides.",
        "Before answering, silently audit the prompt for the required section order, reference-label consistency, exact duration, shot-level composition, subject appearance and position, environment, lighting, actions and state changes, camera movement, synchronized sound, and every connected image. Return a complete production-ready prompt, never a short plot summary.",
    ]
    if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
        parts.append(
            "Return only the final professional Chinese sales storyboard prompt, without commentary."
        )
    elif output_format == "H3 prompt only":
        parts.append("Return only the final optimized H3 prompt, without commentary.")
    else:
        parts.append("Return the final optimized H3 prompt first, then add a short notes section.")

    base_dir = H3_SKILL_ROOT / BASE_SKILL_ID
    _append_file(
        parts,
        base_dir / "SKILL.md",
        f"{BASE_SKILL_ID}/SKILL.md",
    )

    if h3_mode == "Ref2VA":
        _append_file(
            parts,
            base_dir / "references" / "ref-en.txt",
            f"{BASE_SKILL_ID}/references/ref-en.txt",
        )
    else:
        _append_file(
            parts,
            base_dir / "references" / "base-en.txt",
            f"{BASE_SKILL_ID}/references/base-en.txt",
        )

    if skill_id not in {BASE_SKILL_ID, PROFESSIONAL_STORYBOARD_SKILL_ID}:
        skill_dir = H3_SKILL_ROOT / skill_id
        _append_skill_file(
            parts,
            skill_dir,
            skill_id,
            skill_language,
        )
        if reference_depth == "Skill with references":
            _append_reference_files(
                parts,
                skill_dir,
                skill_id,
            )

    if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
        _append_professional_storyboard_role(parts)

    _append_output_language_policy(parts, skill_language)
    return "\n\n---\n\n".join(parts)


def _build_h3_user(
    source_prompt: str,
    extra_requirements: str,
    h3_mode: str,
    duration_seconds: float,
    aspect_ratio: str,
    skill_id: str,
    output_format: str,
    skill_language: str,
    image_indices: list[int],
) -> str:
    if skill_language in {"Chinese if available", "Chinese"}:
        language_policy = (
            "mandatory_output_language: Simplified Chinese. Write all scene descriptions, action descriptions, "
            "style descriptions, camera descriptions, retention analysis, summary, and notes in Simplified Chinese. "
            "Keep only official structural tokens such as subject_definitions, summary, retention_analysis, "
            "detailed_description, [Shot N], <Picture N>, <Subject N>, <d>, model names, and user-provided visible "
            "text/dialogue unchanged. Do not output English descriptive prose."
        )
    elif skill_language == "Both":
        language_policy = (
            "mandatory_output_language: Simplified Chinese first, then English with the same H3 structure."
        )
    else:
        language_policy = "mandatory_output_language: English."

    if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
        detail_floor = max(700, round(duration_seconds * 80))
        detail_policy = (
            f"custom_sales_storyboard_detail_target: Aim for at least {detail_floor} Chinese descriptive characters in the "
            "main timeline when the requested content supports them. Reach the target only with distinct, observable shot-level "
            "composition, identity, environment, lighting, action, material, continuity, and synchronized audio detail; never pad "
            "with repetition or invent unsupported product claims."
        )
    else:
        detail_policy = (
            "official_skill_fidelity: Follow the selected official MiniMax H3 Skill and its mode guide exactly. Do not impose any "
            "extra minimum character count, word count, shot count, segment expansion, or plot expansion beyond the official files. "
            "Use only the amount of detail justified by the user's request and the target duration. Do not invent dialogue, visible "
            "text, locations, products, characters, or story events merely to make the answer longer."
        )

    format_policy = ""
    if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
        format_policy = (
            "\nprofessional_output_contract: Preserve the original exact Chinese bracket-section format: "
            "【全局参数】, 【人物与产品设定】, 【分镜设计】, 【转场要求】, "
            "【镜头与质感要求】, 【音效与音乐】, 【严格约束】. "
            "Keep the original detailed Chinese sales-video director role and dense production-ready output. Treat every concrete "
            "source_prompt and extra_requirements instruction as binding, including requested product features, actions, shot "
            "assignments, transitions, wardrobe or prop states, dialogue conditions, and final-frame state. Do not replace specific "
            "user directions with a generic sales-video template. Define the default visual style as absolute photorealistic, "
            "real-camera, real-person live-commerce or product-demonstration footage, never a short drama, cinematic story, MV, "
            "theatrical performance, or staged narrative advertisement. "
            "Do not create a separate 【口播文案】 section or cue index. Put every speech detail directly inside its corresponding "
            "shot in 【分镜设计】: timing, stable speaker ID and voice, lip-sync or off-screen mode, full exact sentence, speaking "
            "action, mouth visibility, pace, and pauses. Write each exact sentence once and only once using the official inline "
            "syntax (S1) says: <d>[Chinese] ...</d>, beside the visible speaking action and precise mouth-sync requirement. Never "
            "quote, paraphrase, summarize, or restate those words elsewhere. User instructions "
            "about dialogue, cue count, timing, speed, and which "
            "shots lip-sync override every default. If the user gives no lip-sync instruction, make the first suitable shot—"
            "normally Shot 1 beginning at 0.00 seconds with no silent pre-roll, waiting pose, preparatory action, or closed-mouth hold—"
            "a visible mouth-opening, accurate lip-sync sales presentation; "
            "choose visible lip-sync or off-screen voiceover for each later cue according to whether the shot clearly shows a "
            "speaking face. Mark voiceover explicitly with ‘says in an off-screen voiceover’ and keep on-screen lips completely "
            "closed. If the user gives no voice specification, infer a stable suitable natural Mandarin voice from the visible "
            "adult model's apparent age range, gender presentation, temperament, expression, scene, product, and sales style; "
            "when uncertain, use a neutral natural adult voice. Require lifelike breath, micro-pauses, intonation, sentence stress, "
            "pitch movement, and conversational rhythm, never robotic, metallic, monotone, or mechanically even delivery. For an "
            "otherwise unspecified 15-second video, default to a continuous energetic live-commerce delivery across 4-5 "
            "compact cue ranges. Reduce the former fast-script density by about 25% for reliable speech and lip-sync: use about "
            "60-70 spoken Chinese characters total, normally 14-18 characters per cue, at roughly 5.0-5.6 "
            "characters per second. Use connected phrase bursts, crisp stresses, and normally 0.05-0.12 second micro-pauses at "
            "selling-point boundaries. In every shot containing speech, total silence before, inside, and after that shot's line must "
            "be no more than 0.50 second; it may be shorter or zero, and speech may continue directly across a cut. Never slow down "
            "or reset cadence at a shot cut. "
            "Keep dialogue vocabulary varied across shots. Unless exact user dialogue must be preserved, normally say the complete "
            "product name only in the first cue and use 这件、这套、它 or natural omission later. Do not recycle the same selling "
            "adjective, benefit phrase, sentence opening, or CTA wording across multiple <d> blocks; in particular, do not repeatedly "
            "reuse 柔软、舒服、亲肤、宽松、透气、轻盈、自在 or 安心 with only minor rephrasing. Give each cue a distinct semantic "
            "purpose and silently compare all exact dialogue blocks for repeated content words before returning the prompt. "
            "Treat 40-50 total characters and roughly 3.8-4.5 characters per second as medium speed. Use medium or slow speed only "
            "when explicitly requested. If timing is tight, shorten the copy rather than slowing or stretching syllables, and never "
            "sacrifice intelligibility, audio stability, or lip-sync accuracy. Calculate every cue duration from its Chinese character "
            "count excluding punctuation: duration equals character_count divided by the selected characters-per-second rate. At the "
            "default 5.0-5.6 rate, 14 Chinese characters require about 2.5-2.8 seconds, never 0.62 second. Use practical 0.1-second "
            "timestamp precision, make speech occupy nearly all of its shot, and never leave more than 0.50 second of total silence "
            "in a speaking shot. Derive each cue's character target from (its shot duration minus no more than 0.50 second) multiplied "
            "by the selected speaking rate, so a longer shot receives enough copy and does not end with a long silent tail. Every "
            "visible speaking cue must have absolute audio start and end timestamps; the first audible "
            "phoneme and first visible lip/jaw movement start on the same frame, "
            "and the lips close exactly when the cue ends. Unless the user explicitly requests an opening delay, begin the first "
            "on-camera line at 0.00 seconds and do not preserve a closed-mouth reference expression as a timed hold. During the first "
            "spoken cue, keep the face unobstructed and camera locked or nearly locked; do not place eye-contact setup, smiling, "
            "nodding, head movement, hand movement, product demonstration, or camera movement before speech begins. Unless the user "
            "explicitly asks for 一镜到底, one continuous take, or no cuts, require 4-5 purposeful shots rather than one static "
            "presenter view. The first shot establishes presenter and product through immediate lip-sync; each later shot presents "
            "one primary selling point with suitable fabric detail, fit demonstration, functional detail, usage action, transition, "
            "or CTA coverage. Every selling point must be user-provided or conservatively visible; do not invent wash durability, "
            "anti-deformation, breathability, thermal, medical, or other performance claims. Do not impose a speech-free ending; "
            "follow the requested final shot and use off-screen voiceover when "
            "the visible subject is sleeping, occluded, distant, or otherwise should not move their mouth. Use absolute video timestamps and never "
            "restart timing from 0.00 inside a later shot. Do not repeat "
            "dialogue in 【音效与音乐】 or any other "
            "section. Before answering, reconcile global rules with every requested state change and final image. Never describe one "
            "garment as simultaneously worn and placed elsewhere, never simultaneously keep and remove glasses, and never discard a "
            "requested cover transition or final state in favor of a generic continuity rule. State unconditionally that there are "
            "no subtitles or other on-screen text unless the user requests it. "
            "Do not output Markdown, notes, analysis, TOML, JSON, or English descriptive prose."
        )

    return (
        "Optimize this request into a MiniMax H3 prompt.\n\n"
        f"h3_mode: {h3_mode}\n"
        f"target_duration_seconds: {duration_seconds:.2f}\n"
        f"duration_must_match_workflow_seconds: {duration_seconds:.2f}\n"
        "If source_prompt or examples mention another duration, ignore that duration and use "
        "target_duration_seconds exactly.\n"
        f"aspect_ratio: {aspect_ratio}\n"
        f"official_skill: {skill_id}\n"
        f"output_format: {output_format}\n"
        f"{language_policy}\n{detail_policy}{format_policy}\n\n"
        f"connected_reference_image_count: {len(image_indices)}\n"
        + (
            f"Connected image sockets: {', '.join(f'image_{index}' for index in image_indices)}. "
            "Their official Picture numbers must match these socket numbers. "
            "Inspect and account for every connected image; never silently ignore one.\n\n"
            if image_indices
            else "There are no connected reference images. Do not invent Picture or Subject references.\n\n"
        )
        + f"source_prompt:\n{source_prompt.strip()}\n\n"
        f"extra_requirements:\n{extra_requirements.strip() if extra_requirements else 'None'}"
    )


def _detail_floor(duration_seconds: float, h3_mode: str, skill_language: str) -> int:
    if skill_language in {"Chinese if available", "Chinese"}:
        return max(700, round(duration_seconds * 80))
    floor = max(250, round(duration_seconds * 25))
    return max(350, floor) if h3_mode == "Ref2VA" else floor


def _normalize_dialogue_text(text: str) -> str:
    return re.sub(r"[\s，。！？、；：,.!?;:\"'“”‘’]", "", text).casefold()


def _generic_repetition_issues(text: str) -> list[str]:
    """Detect accidental long-form loops without changing official Skill structure."""
    compact = re.sub(r"\s+", "", text).casefold()
    if len(compact) < 160:
        return []

    # An exact 48-character block recurring outside itself is strong evidence of
    # generation looping, while remaining tolerant of normal repeated labels,
    # refrains, product names, and short dialogue.
    window_size = 48
    for start in range(0, len(compact) - window_size + 1):
        block = compact[start:start + window_size]
        if compact.find(block, start + window_size) >= 0:
            return ["generic repetition: output contains a repeated long event block"]
    return []


def _spoken_audio_range(shot_block: str) -> tuple[float, float] | None:
    start_patterns = (
        r"音频\s*从\s*(?:约)?\s*(\d+(?:\.\d+)?)\s*秒\s*开始",
        r"音频\s*(?:起始|开始)\s*(?:于)?\s*(?:约)?\s*(\d+(?:\.\d+)?)\s*秒",
    )
    end_patterns = (
        r"音频\s*(?:结束|停止)\s*(?:于)?\s*(?:约)?\s*(\d+(?:\.\d+)?)\s*秒",
        r"(?:约)?\s*(\d+(?:\.\d+)?)\s*秒\s*(?:结束|停止)",
    )
    start_match = next((re.search(pattern, shot_block) for pattern in start_patterns if re.search(pattern, shot_block)), None)
    end_match = next((re.search(pattern, shot_block) for pattern in end_patterns if re.search(pattern, shot_block)), None)
    if not start_match or not end_match:
        return None
    return float(start_match.group(1)), float(end_match.group(1))


def _professional_prompt_issues(text: str) -> list[str]:
    issues = []
    dialogue_matches = list(re.finditer(r"<d>\s*\[([^\]]+)]\s*(.*?)\s*</d>", text, re.DOTALL | re.IGNORECASE))
    if text.lower().count("<d>") != len(dialogue_matches) or text.lower().count("</d>") != len(dialogue_matches):
        issues.append("dialogue tags are incomplete or do not use <d>[Language] exact words</d>")

    if dialogue_matches and not re.search(r"\(S\d+(?:\s*,\s*S\d+)*\)", text):
        issues.append("spoken dialogue has no stable speaker ID such as (S1)")

    normalized_dialogue = [_normalize_dialogue_text(match.group(2)) for match in dialogue_matches]
    duplicates = sorted({line for line in normalized_dialogue if line and normalized_dialogue.count(line) > 1})
    if duplicates:
        issues.append("one or more spoken lines are repeated in multiple <d> blocks")

    sales_terms = (
        "睡衣", "柔软", "舒服", "亲肤", "宽松", "透气", "轻盈", "自在", "安心", "细腻",
        "上身", "穿着", "睡觉", "不勒", "好看", "耐看", "保暖", "清爽", "贴肤", "放松",
    )
    repeated_sales_terms = [
        term for term in sales_terms
        if sum(term in line for line in normalized_dialogue) > 1
    ]
    if repeated_sales_terms:
        issues.append(
            "spoken copy repeats core sales terms across cue blocks: "
            + "、".join(repeated_sales_terms)
            + "; keep each shot lexically and semantically distinct"
        )

    without_dialogue = re.sub(r"<d>.*?</d>", "", text, flags=re.DOTALL | re.IGNORECASE)
    normalized_without_dialogue = _normalize_dialogue_text(without_dialogue)
    if any(len(line) >= 4 and line in normalized_without_dialogue for line in normalized_dialogue):
        issues.append("spoken words are restated outside their single <d> block")

    if "【口播文案】" in text:
        issues.append("do not create a separate 【口播文案】 section; put all speech details directly inside each speaking shot")

    storyboard_index = text.find("【分镜设计】")
    transition_index = text.find("【转场要求】", storyboard_index)
    if storyboard_index >= 0:
        storyboard_end = transition_index if transition_index >= 0 else len(text)
        storyboard = text[storyboard_index:storyboard_end]
        shot_matches = list(re.finditer(r"(?:分镜\s*|\[Shot\s+)(\d+)", storyboard, re.IGNORECASE))
        for shot_position, shot_match in enumerate(shot_matches):
            if int(shot_match.group(1)) <= 1:
                continue
            block_end = shot_matches[shot_position + 1].start() if shot_position + 1 < len(shot_matches) else len(storyboard)
            shot_block = storyboard[shot_match.start():block_end]
            if re.search(r"(?<![\d.])0(?:\.00+)?\s*(?:秒|s)", shot_block, re.IGNORECASE):
                issues.append("later shots restart timing from 0.00; use absolute timestamps across the whole video")
                break

        for shot_position, shot_match in enumerate(shot_matches):
            block_end = shot_matches[shot_position + 1].start() if shot_position + 1 < len(shot_matches) else len(storyboard)
            shot_block = storyboard[shot_match.start():block_end]
            local_dialogue = list(re.finditer(r"<d>\s*\[[^\]]+]\s*(.*?)\s*</d>", shot_block, re.DOTALL | re.IGNORECASE))
            if not local_dialogue:
                continue
            header = shot_block[:180]
            shot_time = re.search(
                r"(\d+(?:\.\d+)?)\s*(?:秒|s)\s*[-–—至]\s*(\d+(?:\.\d+)?)\s*(?:秒|s)",
                header,
                re.IGNORECASE,
            )
            audio_time = _spoken_audio_range(shot_block)
            if audio_time is None:
                issues.append(
                    f"shot {shot_match.group(1)} has dialogue but no parseable absolute audio start/end time"
                )
                continue
            audio_start, audio_end = audio_time
            spoken_chars = sum(
                len(re.findall(r"[\u3400-\u9fff]", match.group(1)))
                for match in local_dialogue
            )
            audio_duration = audio_end - audio_start
            if audio_duration <= 0:
                issues.append(f"shot {shot_match.group(1)} has a non-positive spoken duration")
            elif spoken_chars and spoken_chars / audio_duration > 6.5:
                issues.append(
                    f"shot {shot_match.group(1)} compresses {spoken_chars} Chinese characters into {audio_duration:.2f}s; "
                    "recalculate at the requested safe speaking rate"
                )
            if shot_time:
                shot_start, shot_end = float(shot_time.group(1)), float(shot_time.group(2))
                boundary_silence = max(0.0, audio_start - shot_start) + max(0.0, shot_end - audio_end)
                if audio_start < shot_start - 0.05 or audio_end > shot_end + 0.05:
                    issues.append(f"shot {shot_match.group(1)} dialogue timing falls outside its shot range")
                if boundary_silence > 0.55:
                    issues.append(
                        f"shot {shot_match.group(1)} leaves {boundary_silence:.2f}s of boundary silence; "
                        "a speaking shot may leave at most 0.50s total and may use less or none"
                    )

    if dialogue_matches and storyboard_index >= 0:
        storyboard_end = transition_index if transition_index >= 0 else len(text)
        if any(not (storyboard_index <= match.start() < storyboard_end) for match in dialogue_matches):
            issues.append("every exact <d> dialogue line must appear once directly inside its corresponding 【分镜设计】 shot")

        missing_inline_syntax = False
        for match in dialogue_matches:
            prefix = text[max(storyboard_index, match.start() - 180):match.start()]
            if not re.search(r"\(S\d+(?:\s*,\s*S\d+)*\).*?says(?:\s+in\s+an\s+off-screen\s+voiceover)?\s*:\s*$", prefix, re.DOTALL | re.IGNORECASE):
                missing_inline_syntax = True
                break
        if missing_inline_syntax:
            issues.append("inline shot dialogue must bind speaker and words with (S1) says: <d>[Chinese] ...</d>")

    if not dialogue_matches and re.search(r"(?:口播|对白|旁白|says|voiceover).{0,100}[“\"]", text, re.DOTALL | re.IGNORECASE):
        issues.append("spoken content is written as prose or quotation instead of one <d>[Language] block")
    return issues


def _prompt_issues(
    text: str,
    h3_mode: str,
    skill_id: str,
    skill_language: str,
    duration_seconds: float,
) -> list[str]:
    if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
        required = [
            "【全局参数】", "【人物与产品设定】", "【分镜设计】",
            "【转场要求】", "【镜头与质感要求】", "【音效与音乐】", "【严格约束】",
        ]
        main_text = text
    elif h3_mode == "Ref2VA":
        required = [
            "subject_definitions:", "summary:", "retention_analysis:",
            "detailed_description:", "overall_soundscape:", "non_diegetic_music:",
        ]
        main_text = text.split("overall_soundscape:", 1)[0]
    else:
        required = [
            "integrated_multimodal_description:",
            "overall_soundscape:",
            "non_diegetic_music:",
        ]
        main_text = text.split("overall_soundscape:", 1)[0]

    issues = [f"missing required section {name}" for name in required if name not in text]
    issues.extend(_generic_repetition_issues(text))
    if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
        issues.extend(_professional_prompt_issues(text))
        floor = _detail_floor(duration_seconds, h3_mode, skill_language)
        if skill_language in {"Chinese if available", "Chinese"}:
            actual = len(re.findall(r"[\u3400-\u9fff]", main_text))
            if actual < floor:
                issues.append(f"main timeline has only {actual} Chinese characters; target at least {floor}")
        else:
            actual = len(re.findall(r"\b[A-Za-z]+(?:[-'][A-Za-z]+)*\b", main_text))
            if actual < floor:
                issues.append(f"main timeline has only {actual} English words; target at least {floor}")
    return issues


def _automatic_context_size(
    system_text: str,
    user_text: str,
    image_count: int,
    max_output_tokens: int,
) -> int:
    estimated_tokens = (
        (len(system_text) + len(user_text) + 3) // 4
        + image_count * 2048
        + max_output_tokens * 2
        + 2048
    )
    if estimated_tokens <= 28672:
        return DEFAULT_BONSAI_CONTEXT_SIZE
    if estimated_tokens <= 57344:
        return EXPANDED_BONSAI_CONTEXT_SIZE
    return MAX_BONSAI_CONTEXT_SIZE


class XinbaoH3PromptOptimizer:
    """MiniMax H3 prompt optimizer powered by the local Bonsai model."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "max_side": (
                    "INT",
                    {"default": 512, "min": 256, "max": 2048, "step": 64},
                ),
                "h3_skill": (
                    _skill_choices(),
                    {
                        "default": SKILL_NAMES[BASE_SKILL_ID],
                        "tooltip": "选择内容角色；中文带货视频默认多分镜逐项展示卖点，首镜头从 0 秒立即对口型；只有用户明确要求一镜到底时才使用单镜头。15 秒默认约 60–70 字，采用稳妥快速的真人口播。",
                    },
                ),
                "h3_mode": (list(H3_MODES), {"default": "文本生成视频 (T2VA)"}),
                "duration_seconds": (
                    "FLOAT",
                    {"default": 6.0, "min": 4.0, "max": 15.0, "step": 0.5},
                ),
                "aspect_ratio": (list(ASPECT_RATIOS), {"default": "16:9"}),
                "megapixels": (
                    "FLOAT",
                    {"default": DEFAULT_MEGAPIXELS, "min": 0.1, "max": 16.0, "step": 0.1},
                ),
                "skill_language": (list(SKILL_LANGUAGE), {"default": "严格遵循官方（英文）"}),
                "reference_depth": (list(REFERENCE_DEPTH), {"default": "Skill 与参考资料"}),
                "output_format": (list(OUTPUT_FORMAT), {"default": "仅输出 H3 提示词"}),
                "source_prompt": (
                    "STRING",
                    {
                        "default": "一段电影感短视频提示词。",
                        "multiline": True,
                    },
                ),
                "extra_requirements": (
                    "STRING",
                    {
                        "default": "",
                        "multiline": True,
                    },
                ),
                "temperature": (
                    "FLOAT",
                    {"default": 0.4, "min": 0.1, "max": 1.0, "step": 0.1},
                ),
                "top_p": (
                    "FLOAT",
                    {"default": 0.9, "min": 0.0, "max": 1.0, "step": 0.01},
                ),
                "max_new_tokens": (
                    "INT",
                    {"default": 3072, "min": 512, "max": 8192, "step": 128},
                ),
                "seed": (
                    "INT",
                    {
                        "default": -1,
                        "min": -1,
                        "max": 0x7FFFFFFF,
                        "control_after_generate": True,
                    },
                ),
                "release_comfy_vram": ("BOOLEAN", {"default": True}),
                "keep_model_loaded": ("BOOLEAN", {"default": False}),
            },
            "optional": {
                "workflow_width": ("INT",),
                "workflow_height": ("INT",),
                "workflow_duration": ("FLOAT",),
                **{f"image_{index}": ("IMAGE",) for index in range(1, 11)},
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("H3提示词",)
    FUNCTION = "forward"
    OUTPUT_NODE = True
    CATEGORY = "心宝❤推理（极速版）"
    DESCRIPTION = "使用本地 Ternary Bonsai 2 27B 和官方 H3 Skill 生成 MiniMax H3 专用提示词。"

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        seed = kwargs.get("seed", -1)
        return float("nan") if seed is None or seed < 0 else seed

    def forward(self, **kwargs):
        skill_id = _normalize_skill(kwargs["h3_skill"])
        h3_mode = _normalize_choice(kwargs["h3_mode"], H3_MODES)
        skill_language = _normalize_choice(kwargs["skill_language"], SKILL_LANGUAGE)
        reference_depth = _normalize_choice(kwargs["reference_depth"], REFERENCE_DEPTH)
        output_format = _normalize_choice(kwargs["output_format"], OUTPUT_FORMAT)
        if output_format in {"Professional Chinese sales storyboard", "专业中文分镜带货格式", "中文带货视频"}:
            skill_id = PROFESSIONAL_STORYBOARD_SKILL_ID
            output_format = "H3 prompt only"
        width = int(kwargs.get("workflow_width") or 0)
        height = int(kwargs.get("workflow_height") or 0)
        if width < H3_CANVAS_MULTIPLE or height < H3_CANVAS_MULTIPLE:
            aspect_ratio = _normalize_aspect_ratio(kwargs["aspect_ratio"])
            width, height = _h3_resolution(
                aspect_ratio,
                _normalize_megapixels(kwargs["megapixels"]),
            )
        else:
            aspect_ratio = _aspect_ratio_from_dimensions(width, height)

        duration_seconds = _normalize_duration(
            kwargs.get("workflow_duration"),
            _normalize_duration(kwargs["duration_seconds"]),
        )
        max_new_tokens = min(int(kwargs["max_new_tokens"]), MAX_CHAT_NEW_TOKENS)
        if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
            max_new_tokens = max(max_new_tokens, PROFESSIONAL_MIN_NEW_TOKENS)

        image_indices = [
            index for index in range(1, 11) if kwargs.get(f"image_{index}") is not None
        ]
        system_text = _build_h3_system(
            skill_id,
            h3_mode,
            skill_language,
            reference_depth,
            output_format,
        )
        user_text = _build_h3_user(
            kwargs["source_prompt"],
            kwargs["extra_requirements"],
            h3_mode,
            duration_seconds,
            aspect_ratio,
            skill_id,
            output_format,
            skill_language,
            image_indices,
        )

        if kwargs["release_comfy_vram"]:
            _release_comfy_models()

        model = _find_one(BONSAI_MODEL_DIR, "*PTQ1_0.gguf")
        mmproj = _find_one(BONSAI_MODEL_DIR, "*mmproj-Q8_0.gguf")
        context_size = _automatic_context_size(
            system_text,
            user_text,
            len(image_indices),
            max_new_tokens,
        )
        SERVER.ensure(
            BONSAI_RUNTIME_DIR,
            model,
            mmproj,
            context_size,
        )

        content = []
        for index in image_indices:
            image = kwargs[f"image_{index}"]
            pil = _tensor_frame_to_pil(image, int(kwargs["max_side"]))
            content.append({"type": "text", "text": f"H3 reference image_{index}"})
            content.append(
                {
                    "type": "image_url",
                    "image_url": {"url": _data_url(pil, quality=90)},
                }
            )
        content.append({"type": "text", "text": user_text})

        seed = int(kwargs["seed"])
        if seed < 0:
            seed = random.randint(0, 0x7FFFFFFF)
        payload = {
            "model": model.name,
            "messages": [
                {"role": "system", "content": system_text},
                {"role": "user", "content": content},
            ],
            "temperature": kwargs["temperature"],
            "top_p": kwargs["top_p"],
            "max_tokens": max_new_tokens,
            "seed": seed,
            "reasoning_effort": "none",
            "chat_template_kwargs": {"enable_thinking": False},
            "stream": False,
        }
        try:
            result = _post_json(SERVER.endpoint(), payload, timeout=1200)
            text = _clean_prompt(result["choices"][0]["message"]["content"])
            if not text:
                raise RuntimeError(f"Bonsai 模型返回了空结果：{result}")
            issues = _prompt_issues(
                text,
                h3_mode,
                skill_id,
                skill_language,
                duration_seconds,
            )
            missing_sections = [issue for issue in issues if issue.startswith("missing required section")]
            repetition_issues = [issue for issue in issues if issue.startswith("generic repetition:")]
            if missing_sections or repetition_issues or skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID:
                audit_issues = issues or [
                    "perform the final dense Chinese sales-storyboard consistency pass without changing its role or structure"
                ]
                professional_repair_rule = (
                    " Preserve the seven required Chinese bracket sections and remove any separate 【口播文案】 section or cue "
                    "index. Put every speech detail—time, speaker and stable voice, delivery mode, full exact words, mouth action, "
                    "pace, and pauses—directly inside its speaking shot in 【分镜设计】. Put each exact spoken line once and only "
                    "once using "
                    "(S1) says: <d>[Chinese] ...</d>, adjacent to the visible mouth-opening and precise lip-sync action. User "
                    "instructions about dialogue and lip-sync have highest "
                    "priority. If the user did not specify lip-sync, make the first suitable shot a visible mouth-opening accurate "
                    "lip-sync presentation, then choose later lip-sync or explicitly marked off-screen voiceover according to the "
                    "shot. If the user did not specify a voice, infer one stable natural human Mandarin voice from the visible "
                    "adult model and product mood; explicitly forbid robotic, metallic, monotone, mechanically even delivery. "
                    "For an otherwise unspecified 15-second video, use one continuous energetic sales delivery organized into 4-5 "
                    "cue ranges. Reduce the former fast-script density by about 25% for reliability: total about 60-70 Chinese "
                    "characters, normally 14-18 characters per cue, at 5.0-5.6 characters per second. Use connected phrase "
                    "bursts and emphatic selling-point stresses. In every shot containing speech, total silence before, inside, and "
                    "after that shot's line must not exceed 0.50 second; it may be shorter or zero, and speech may continue directly "
                    "across a cut. Unless exact user dialogue must be preserved, make dialogue lexically diverse across all cues: "
                    "normally use the full product name once in the first cue, use natural pronouns or omission later, and do not "
                    "repeat core adjectives, benefits, openings, CTA wording, or near-duplicate sentence structures. Specifically "
                    "audit repeated terms such as 柔软、舒服、亲肤、宽松、透气、轻盈、自在 and 安心 and rewrite each cue to have "
                    "a distinct semantic job. Unless the user explicitly requests a delayed opening, start the first on-camera "
                    "sales line at 0.00 seconds with no silent pre-roll, waiting pose, or closed-mouth hold; make the first audible "
                    "phoneme and first visible lip/jaw movement start on exactly the same frame. Keep the camera locked or nearly "
                    "locked during that first cue and do not put a preparatory action before speech. Unless the user explicitly asks "
                    "for one continuous take or 一镜到底, require 4-5 purposeful shots rather than a single static presenter shot: "
                    "the first shot establishes presenter and product through immediate lip-sync, and each later shot demonstrates "
                    "one primary selling point with suitable product detail, fit, function, usage, transition, or CTA coverage. "
                    "Integrate every concrete user-requested action, transition, object or wardrobe state, final-frame condition, and "
                    "speaking requirement into its exact shot. Calculate duration as Chinese character count excluding punctuation "
                    "divided by the chosen speaking rate; at 5.0-5.6 characters per second, 14 characters require about 2.5-2.8 "
                    "seconds, never 0.62 second. Use 0.1-second timing precision and calculate the cue length from (shot duration minus "
                    "no more than 0.50 second) multiplied by the speaking rate, so speech occupies nearly all of its shot. Give "
                    "every visible speaking cue absolute audio start and end timestamps, close the lips exactly when each cue ends, never let audio lead mouth motion, and never restart "
                    "timing from 0.00 in a later shot. Do not impose a speech-free ending; use off-screen voiceover when the requested "
                    "final image contains a sleeping, occluded, distant, or otherwise non-speaking visible subject. Do not invent "
                    "unsupported product-performance claims. Reconcile every global constraint with shot-level state changes: a "
                    "garment cannot be both worn and placed elsewhere, glasses cannot be both present and absent, and a requested "
                    "cover transition or final state must not be discarded. Define the default "
                    "look as absolute photorealistic real-camera live-commerce footage, never a short drama, cinematic narrative, MV, "
                    "or staged advertising performance. "
                    "Treat 40-50 characters at 3.8-4.5 characters per second as medium speed and use it only when requested. If a "
                    "cue is overloaded, shorten its copy rather than slowing or stretching syllables; preserve pronunciation and lip-sync stability."
                    if skill_id == PROFESSIONAL_STORYBOARD_SKILL_ID
                    else ""
                )
                official_repair_rule = (
                    " For an official Skill, preserve its exact required structure and mode rules. Remove every duplicated long "
                    "event chain instead of extending it, and do not add any minimum length, extra shots, dialogue, visible text, "
                    "locations, characters, products, or plot events not requested by the user or required by the official Skill."
                    if skill_id != PROFESSIONAL_STORYBOARD_SKILL_ID
                    else ""
                )
                repair_messages = [
                    *payload["messages"],
                    {"role": "assistant", "content": text},
                    {
                        "role": "user",
                        "content": (
                            "Rewrite the draft in full. It failed the final H3 compliance audit for these reasons:\n- "
                            + "\n- ".join(audit_issues)
                            + "\nFollow the complete official guide already provided in the system message. "
                            "Preserve the user's intent, exact duration, all connected references, and required output language. "
                            "Add concrete shot-level composition, subject, environment, action, camera, lighting, material, continuity, "
                            "and synchronized audio detail instead of repetition."
                            + professional_repair_rule
                            + official_repair_rule
                            + " Output only the complete replacement prompt."
                        ),
                    },
                ]
                repair_payload = {
                    **payload,
                    "messages": repair_messages,
                    "temperature": min(float(kwargs["temperature"]), 0.2),
                    "max_tokens": min(MAX_CHAT_NEW_TOKENS, max(max_new_tokens, 4096)),
                }
                repair = _post_json(SERVER.endpoint(), repair_payload, timeout=1200)
                repaired_text = _clean_prompt(repair["choices"][0]["message"]["content"])
                if repaired_text:
                    text = repaired_text
            return {"ui": {"text": (text,)}, "result": (text,)}
        finally:
            if not kwargs["keep_model_loaded"]:
                SERVER.stop()


# Keep the legacy class name so existing H3 workflows load without relinking.
Qwen3VL_Li_H3PromptOptimizer = XinbaoH3PromptOptimizer
