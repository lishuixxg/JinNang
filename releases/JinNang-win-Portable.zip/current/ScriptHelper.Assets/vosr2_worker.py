# -*- coding: utf-8 -*-
"""VOSR 2.0 超分 worker（锦囊调用）。

不启动 ComfyUI 服务，直接复用本机 ComfyUI 的 Python 环境与 ComfyUI-VOSR2 扩展代码：
    python_embeded/python.exe vosr2_worker.py --comfy-root <ComfyUI代码目录> --ext-dir <扩展目录> --models-root <models目录>

任务以单行 JSON 从 stdin 传入：
    {"inputs": ["a.png"], "out_dir": "...", "upscale": 2, "tile_size": 512,
     "tile_overlap": 32, "vae_tile_size": 1024, "vae_tile_overlap": 32,
     "color_alignment": "wavelet", "seed": 42, "dtype": "default"}

结果以单行 JSON 输出到 stdout：
    {"type":"progress","percent":0.42,"stage":"infer","msg":"..."}
    {"type":"done","outputs":["..."]}
    {"type":"error","msg":"..."}
"""
import argparse
import importlib
import json
import os
import sys
import time
import traceback
import types


def emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def log(msg):
    emit({"type": "log", "msg": str(msg)})


def progress(percent, stage, msg=""):
    emit({"type": "progress", "percent": round(float(percent), 4), "stage": stage, "msg": msg})


def load_extension(comfy_root, ext_dir, models_root):
    """把 ComfyUI 根目录放进 sys.path，再以虚拟包方式加载扩展（目录名带连字符，不能直接 import）。"""
    if comfy_root not in sys.path:
        sys.path.insert(0, comfy_root)

    import folder_paths  # noqa: E402

    folder_paths.models_dir = models_root

    if "vosr2_ext" not in sys.modules:
        pkg = types.ModuleType("vosr2_ext")
        pkg.__path__ = [ext_dir]
        sys.modules["vosr2_ext"] = pkg

    loader = importlib.import_module("vosr2_ext.loader")
    inference = importlib.import_module("vosr2_ext.inference")
    return loader, inference


def ensure_dinov2(loader, models_root):
    """官方只发布 dinov2_vitl14_pretrain.pth，扩展需要同目录的 dinov2_vitl14.safetensors。"""
    from pathlib import Path

    bundle = Path(models_root) / "vosr2" / "VOSR2"
    target = bundle / "dinov2_vitl14.safetensors"
    if target.is_file() and target.stat().st_size > 0:
        return
    src = bundle / "dinov2_vitl14_pretrain.pth"
    if not src.is_file():
        raise RuntimeError("缺少 DINOv2 权重：%s" % src)
    progress(0.02, "convert", "首次运行：正在把 DINOv2 权重转换为 safetensors")
    loader._convert_dinov2_pth_to_safetensors(src, target)
    log("DINOv2 转换完成：%s" % target)


def run_job(job, loader, inference, models_root):
    import numpy as np
    import torch
    from PIL import Image

    inputs = [p for p in job.get("inputs", []) if p]
    if not inputs:
        raise RuntimeError("没有输入文件")
    out_dir = job.get("out_dir") or os.path.dirname(inputs[0])
    os.makedirs(out_dir, exist_ok=True)

    dtype = job.get("dtype") or "default"
    upscale = int(job.get("upscale", 2))
    tile_size = int(job.get("tile_size", 512))
    tile_overlap = int(job.get("tile_overlap", 32))
    vae_tile_size = int(job.get("vae_tile_size", 1024))
    vae_tile_overlap = int(job.get("vae_tile_overlap", 32))
    color = job.get("color_alignment") or "wavelet"
    seed = int(job.get("seed", 42))

    ensure_dinov2(loader, models_root)

    progress(0.05, "load", "加载 VOSR 2.0 模型（约 5.6 GB，首次较慢）")
    t0 = time.time()
    model = loader.load_vosr2("VOSR2", dtype)
    log("模型加载完成，用时 %.1f 秒（设备 %s）" % (time.time() - t0, getattr(model.dit_patcher, "load_device", "?")))
    emit({"type": "vram", "text": describe_vram(torch)})

    outputs = []
    total = len(inputs)
    for idx, src in enumerate(inputs):
        base = 0.08 + (idx / max(1, total)) * 0.90
        span = 0.90 / max(1, total)
        name = os.path.basename(src)
        progress(base + span * 0.05, "read", "读取 %s" % name)

        try:
            img = Image.open(src).convert("RGB")
        except Exception as exc:
            log("跳过无法解码的文件 %s：%s" % (src, exc))
            continue

        w, h = img.size
        arr = np.asarray(img).astype(np.float32) / 255.0
        tensor = torch.from_numpy(arr)[None]

        progress(base + span * 0.2, "infer", "推理 %s（%dx%d → %dx%d）" % (name, w, h, w * upscale, h * upscale))
        t1 = time.time()
        out = inference.run_vosr2(
            model,
            tensor,
            upscale,
            seed,
            color,
            tile_size,
            tile_overlap,
            vae_tile_size,
            vae_tile_overlap,
        )
        cost = time.time() - t1

        progress(base + span * 0.85, "save", "保存 %s" % name)
        out_arr = out.clamp(0, 1)[0].cpu().numpy()
        out_img = Image.fromarray((out_arr * 255.0 + 0.5).astype(np.uint8))
        stem, _ = os.path.splitext(name)
        dst = os.path.join(out_dir, "%s_%dx.png" % (stem, upscale))
        n = 1
        while os.path.exists(dst):
            dst = os.path.join(out_dir, "%s_%dx_%d.png" % (stem, upscale, n))
            n += 1
        out_img.save(dst)
        outputs.append(dst)
        log("%s 完成（%dx%d，用时 %.1f 秒）→ %s" % (name, out_img.size[0], out_img.size[1], cost, dst))
        del tensor
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    return outputs


def describe_vram(torch):
    try:
        if not torch.cuda.is_available():
            return "未检测到 CUDA，将在 CPU 上运行（极慢）"
        free, total = torch.cuda.mem_get_info()
        return "显存占用 %.1f/%.1f GB" % ((total - free) / 1024 ** 3, total / 1024 ** 3)
    except Exception:
        return ""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--comfy-root", required=True)
    parser.add_argument("--ext-dir", required=True)
    parser.add_argument("--models-root", required=True)
    args = parser.parse_args()

    sys.stderr.write("worker start\n")
    sys.stderr.flush()

    try:
        loader, inference = load_extension(args.comfy_root, args.ext_dir, args.models_root)
    except Exception:
        emit({"type": "error", "msg": "扩展加载失败：\n" + traceback.format_exc()})
        return 2

    emit({"type": "ready"})

    line = sys.stdin.readline()
    if not line:
        emit({"type": "error", "msg": "未收到任务"})
        return 3
    try:
        job = json.loads(line)
    except Exception:
        emit({"type": "error", "msg": "任务 JSON 解析失败"})
        return 3

    try:
        outputs = run_job(job, loader, inference, args.models_root)
        emit({"type": "done", "outputs": outputs})
        return 0
    except Exception:
        emit({"type": "error", "msg": traceback.format_exc()})
        return 1


if __name__ == "__main__":
    sys.exit(main())
